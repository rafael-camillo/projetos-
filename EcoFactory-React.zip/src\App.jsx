import { useMemo, useState } from 'react'
import { initialMachines, initialOccurrences, production } from './data'
import { BarChart, EmptyState, MetricCard, StatusTag } from './components'

const pages = {
  dashboard: { label: 'Visão geral', eyebrow: 'PAINEL OPERACIONAL', title: 'Olá, Administrador!', sub: 'Visão geral da operação industrial.' },
  machines: { label: 'Máquinas', eyebrow: 'GESTÃO INDUSTRIAL', title: 'Máquinas', sub: 'Controle e acompanhe seus equipamentos.' },
  production: { label: 'Produção', eyebrow: 'OPERAÇÃO', title: 'Produção', sub: 'Acompanhe resultados e metas em tempo real.' },
  sustainability: { label: 'Sustentabilidade', eyebrow: 'IMPACTO AMBIENTAL', title: 'Sustentabilidade', sub: 'Monitore metas ambientais e consumo de recursos.' },
  safety: { label: 'Segurança', eyebrow: 'SAÚDE E SEGURANÇA', title: 'Segurança', sub: 'Indicadores de segurança e gestão de ocorrências.' },
}

const blankMachine = { name: '', code: '', sector: '', status: 'Operando', efficiency: '', maintenance: '' }
const blankOccurrence = { event: '', location: '', severity: 'Baixa', status: 'Em análise', date: '' }

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [machines, setMachines] = useState(initialMachines)
  const [occurrences, setOccurrences] = useState(initialOccurrences)
  const [machineForm, setMachineForm] = useState(null)
  const [occurrenceForm, setOccurrenceForm] = useState(false)
  const [filter, setFilter] = useState('Todos')
  const [search, setSearch] = useState('')
  const [notice, setNotice] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)

  const showNotice = (text) => { setNotice(text); window.setTimeout(() => setNotice(''), 2600) }
  const operating = machines.filter(m => m.status === 'Operando').length
  const filteredMachines = useMemo(() => machines.filter(m => (filter === 'Todos' || m.status === filter) && `${m.name} ${m.code} ${m.sector}`.toLowerCase().includes(search.toLowerCase())), [machines, filter, search])
  const changePage = (key) => { setPage(key); setMenuOpen(false); setMachineForm(null); setOccurrenceForm(false) }

  function saveMachine(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const record = { ...machineForm, id: machineForm?.id || Date.now(), name: form.get('name'), code: form.get('code'), sector: form.get('sector'), status: form.get('status'), efficiency: Number(form.get('efficiency')), maintenance: form.get('maintenance') }
    setMachines(current => machineForm?.id ? current.map(item => item.id === record.id ? record : item) : [...current, record])
    setMachineForm(null); showNotice(machineForm?.id ? 'Máquina atualizada com sucesso.' : 'Máquina cadastrada com sucesso.')
  }
  function saveOccurrence(event) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    setOccurrences(current => [{ id: Date.now(), event: form.get('event'), location: form.get('location'), severity: form.get('severity'), status: form.get('status'), date: form.get('date') || new Date().toLocaleDateString('pt-BR') }, ...current])
    setOccurrenceForm(false); showNotice('Ocorrência registrada com sucesso.')
  }
  function deleteMachine(id) { setMachines(current => current.filter(item => item.id !== id)); showNotice('Máquina removida do cadastro.') }

  return <div className="app-shell">
    <aside className={`sidebar ${menuOpen ? 'open' : ''}`}>
      <button className="brand" onClick={() => changePage('dashboard')}><b>E</b><span>EcoFactory<small>INDUSTRIAL INTELLIGENCE</small></span></button>
      <nav>{Object.entries(pages).map(([key, item]) => <button className={page === key ? 'active' : ''} onClick={() => changePage(key)} key={key}><span>{({ dashboard: '▦', machines: '⚙', production: '◒', sustainability: '♧', safety: '⌾' })[key]}</span>{item.label}</button>)}</nav>
      <div className="profile"><i>AM</i><span><b>Administrador</b><small>Operações</small></span></div>
    </aside>
    <main>
      <header><div className="heading"><button className="menu-button" onClick={() => setMenuOpen(!menuOpen)}>☰</button><div><span className="eyebrow">{pages[page].eyebrow}</span><h1>{pages[page].title}</h1><p>{pages[page].sub}</p></div></div><span className="online">Sistema online</span></header>
      {page === 'dashboard' && <Dashboard machines={machines} operating={operating} />}
      {page === 'machines' && <Machines machines={filteredMachines} total={machines.length} filter={filter} search={search} onFilter={setFilter} onSearch={setSearch} onAdd={() => setMachineForm(blankMachine)} onEdit={setMachineForm} onDelete={deleteMachine} />}
      {page === 'production' && <Production />}
      {page === 'sustainability' && <Sustainability />}
      {page === 'safety' && <Safety occurrences={occurrences} onAdd={() => setOccurrenceForm(true)} />}
    </main>
    {machineForm && <MachineModal machine={machineForm} onClose={() => setMachineForm(null)} onSave={saveMachine} />}
    {occurrenceForm && <OccurrenceModal onClose={() => setOccurrenceForm(false)} onSave={saveOccurrence} />}
    {notice && <div className="toast" role="status">{notice}</div>}
  </div>
}

function Dashboard({ machines, operating }) { return <>
  <section className="metrics"><MetricCard icon="⚙" label="Máquinas em operação" value={`${operating} / ${machines.length}`} note="Dados do cadastro" /><MetricCard icon="◒" tone="purple" label="Produção do dia" value="12.840 un." note="↑ 8,5% vs. ontem" /><MetricCard icon="♧" tone="green" label="Eficiência energética" value="92,4%" note="↑ 1,8% no mês" /><MetricCard icon="⌾" tone="amber" label="Índice de segurança" value="98,7%" note="↑ 0,4% no período" /></section>
  <section className="grid wide"><article className="panel"><PanelTitle title="Produção semanal" subtitle="Unidades produzidas por dia" /><BarChart data={production} /></article><article className="panel"><PanelTitle title="Status das máquinas" subtitle="Atualizado com os dados locais" /><div className="status-summary"><div><b>{operating}</b><span>Em operação</span></div><div><b>{machines.filter(m => m.status === 'Manutenção').length}</b><span>Em manutenção</span></div><div><b>{machines.filter(m => m.status === 'Parada').length}</b><span>Paradas</span></div></div><div className="stack"><i style={{ width: `${operating / machines.length * 100}%` }} /><i style={{ width: `${machines.filter(m => m.status === 'Manutenção').length / machines.length * 100}%` }} /><i style={{ width: `${machines.filter(m => m.status === 'Parada').length / machines.length * 100}%` }} /></div><div className="compact-list">{machines.slice(0, 3).map(m => <div key={m.id}><span><b>{m.name}</b><small>{m.sector} · {m.efficiency}% eficiência</small></span><StatusTag value={m.status} /></div>)}</div></article></section>
  <section className="grid equal"><article className="panel"><PanelTitle title="Sustentabilidade" subtitle="Consumo e metas ambientais" /><Progress label="Consumo de água" text="1.245 m³ de 1.500 m³" value={83} /><Progress label="Energia renovável" text="68% da energia consumida" value={68} green /><Progress label="Resíduos reciclados" text="4,8 t no mês atual" value={76} /></article><article className="panel"><PanelTitle title="Alertas recentes" subtitle="Itens que precisam de atenção" /><div className="compact-list"><div><span><b>Manutenção programada</b><small>Esteira Transportadora 02 · Hoje, 14:00</small></span><StatusTag value="Atenção" /></div><div><span><b>Consumo de água elevado</b><small>12% acima da média diária</small></span><StatusTag value="Alerta" /></div><div><span><b>Meta de produção atingida</b><small>Linha A · 102% da meta</small></span><StatusTag value="Concluída" /></div></div></article></section>
</> }

function Machines({ machines, total, filter, search, onFilter, onSearch, onAdd, onEdit, onDelete }) { return <>
  <section className="metrics three"><MetricCard icon="⚙" label="Total de máquinas" value={total} note="Cadastro local" /><MetricCard icon="✓" tone="green" label="Operando normalmente" value={machines.filter(m => m.status === 'Operando').length} note="Dados filtrados" /><MetricCard icon="⌁" tone="amber" label="Requerem atenção" value={machines.filter(m => m.status !== 'Operando').length} note="Manutenção ou parada" /></section>
  <section className="panel"><div className="panel-title actions"><div><h2>Lista de máquinas</h2><p>Cadastre, filtre, edite ou exclua equipamentos.</p></div><button className="primary" onClick={onAdd}>+ Adicionar máquina</button></div><div className="filters"><input aria-label="Buscar máquina" placeholder="Buscar por máquina, código ou setor" value={search} onChange={e => onSearch(e.target.value)} /><select value={filter} onChange={e => onFilter(e.target.value)}><option>Todos</option><option>Operando</option><option>Manutenção</option><option>Parada</option></select></div><MachineTable machines={machines} onEdit={onEdit} onDelete={onDelete} /></section>
</> }

function MachineTable({ machines, onEdit, onDelete }) { if (!machines.length) return <EmptyState>Nenhuma máquina encontrada para este filtro.</EmptyState>; return <div className="table-wrap"><table><thead><tr><th>Máquina</th><th>Setor</th><th>Status</th><th>Eficiência</th><th>Última manutenção</th><th aria-label="Ações" /></tr></thead><tbody>{machines.map(m => <tr key={m.id}><td><b>{m.name}</b><small>{m.code}</small></td><td>{m.sector}</td><td><StatusTag value={m.status} /></td><td>{m.efficiency}%</td><td>{m.maintenance}</td><td className="row-actions"><button onClick={() => onEdit(m)}>Editar</button><button className="delete" onClick={() => onDelete(m.id)}>Excluir</button></td></tr>)}</tbody></table></div> }

function Production() { return <><section className="metrics"><MetricCard icon="◒" tone="purple" label="Produção hoje" value="12.840 un." note="↑ 8,5% vs. ontem" /><MetricCard icon="◎" label="Meta diária" value="91,7%" note="12.840 de 14.000 un." /><MetricCard icon="↗" tone="green" label="Produtividade" value="86,3%" note="↑ 2,1% esta semana" /><MetricCard icon="◆" tone="amber" label="Refugo" value="1,8%" note="↓ 0,3% vs. meta" /></section><section className="grid wide"><article className="panel"><PanelTitle title="Produção por turno" subtitle="Unidades produzidas nos últimos 7 dias" /><BarChart data={production} color="purple" /></article><article className="panel"><PanelTitle title="Produção por linha" subtitle="Participação no total" /><div className="donut"><b>12.840</b></div><div className="legend"><span>Linha A <b>45%</b></span><span>Linha B <b>31%</b></span><span>Linha C <b>24%</b></span></div></article></section><section className="panel"><PanelTitle title="Metas por linha" subtitle="Desempenho do dia atual" />{[['Linha de montagem A', '6.210 / 6.000 un.', 100, '103,5%'], ['Linha de montagem B', '3.980 / 4.500 un.', 88, '88,4%'], ['Linha de montagem C', '2.650 / 3.500 un.', 76, '75,7%']].map(([name, text, value, result]) => <div className="goal" key={name}><span><b>{name}</b><small>{text}</small></span><div className="progress"><i style={{ width: `${value}%` }} /></div><b>{result}</b></div>)}</section></> }

function Sustainability() { return <><section className="metrics"><MetricCard icon="◉" label="Consumo de água" value="1.245 m³" note="↓ 6,4% no mês" /><MetricCard icon="ϟ" tone="amber" label="Energia consumida" value="28,4 MWh" note="68% de fonte renovável" /><MetricCard icon="♺" tone="green" label="Resíduos reciclados" value="4,8 t" note="76% do total gerado" /><MetricCard icon="☁" tone="purple" label="Emissões de CO₂" value="12,6 t" note="↓ 11% no mês" /></section><section className="grid equal"><article className="panel"><PanelTitle title="Consumo de água" subtitle="m³ por semana" /><BarChart data={production} /></article><article className="panel"><PanelTitle title="Matriz energética" subtitle="Origem do consumo mensal" /><div className="donut energy"><b>68%</b></div><div className="legend"><span>Solar <b>42%</b></span><span>Hidrelétrica <b>26%</b></span><span>Rede convencional <b>32%</b></span></div></article></section></> }

function Safety({ occurrences, onAdd }) { return <><section className="metrics"><MetricCard icon="⌾" tone="green" label="Índice de segurança" value="98,7%" note="↑ 0,4% últimos 30 dias" /><MetricCard icon="◉" label="Dias sem acidentes" value="187" note="Recorde: 215 dias" /><MetricCard icon="!" tone="amber" label="Ocorrências no mês" value={occurrences.length} note="Dados do registro local" /><MetricCard icon="✓" tone="purple" label="Treinamentos em dia" value="94%" note="226 de 240 colaboradores" /></section><section className="grid equal"><article className="panel"><PanelTitle title="Ocorrências por categoria" subtitle="Últimos 6 meses" />{[['Quase acidente', 82, 12], ['Condição insegura', 58, 8], ['Acidente sem afastamento', 29, 4], ['Acidente com afastamento', 8, 1]].map(([label, value, number]) => <div className="horizontal-bar" key={label}><span>{label}</span><i><b style={{ width: `${value}%` }} /></i><strong>{number}</strong></div>)}</article><article className="panel"><PanelTitle title="Meta: zero acidentes" subtitle="Progresso anual" /><div className="donut safety"><b>98,7%</b></div><p className="center-note">A operação está dentro da meta de segurança de 2026.</p></article></section><section className="panel"><div className="panel-title actions"><div><h2>Histórico de ocorrências</h2><p>Registro de eventos recentes.</p></div><button className="primary" onClick={onAdd}>+ Nova ocorrência</button></div><div className="table-wrap"><table><thead><tr><th>Data</th><th>Ocorrência</th><th>Local</th><th>Gravidade</th><th>Status</th></tr></thead><tbody>{occurrences.map(item => <tr key={item.id}><td>{item.date}</td><td>{item.event}</td><td>{item.location}</td><td><StatusTag value={item.severity} /></td><td><StatusTag value={item.status} /></td></tr>)}</tbody></table></div></section></> }

function PanelTitle({ title, subtitle }) { return <div className="panel-title"><div><h2>{title}</h2><p>{subtitle}</p></div></div> }
function Progress({ label, text, value, green }) { return <div className="progress-row"><b>{label}</b><small>{text}</small><div className={`progress ${green ? 'green' : ''}`}><i style={{ width: `${value}%` }} /></div></div> }

function Modal({ title, children, onClose }) { return <div className="modal-backdrop" role="dialog" aria-modal="true" aria-label={title}><section className="modal"><div className="modal-top"><h2>{title}</h2><button onClick={onClose} aria-label="Fechar">×</button></div>{children}</section></div> }
function MachineModal({ machine, onClose, onSave }) { return <Modal title={machine.id ? 'Editar máquina' : 'Nova máquina'} onClose={onClose}><form onSubmit={onSave}><div className="form-grid"><label>Nome<input name="name" defaultValue={machine.name} required /></label><label>Código<input name="code" defaultValue={machine.code} required /></label><label>Setor<input name="sector" defaultValue={machine.sector} required /></label><label>Status<select name="status" defaultValue={machine.status}><option>Operando</option><option>Manutenção</option><option>Parada</option></select></label><label>Eficiência (%)<input name="efficiency" type="number" min="0" max="100" defaultValue={machine.efficiency} required /></label><label>Última manutenção<input name="maintenance" placeholder="dd/mm/aaaa" defaultValue={machine.maintenance} required /></label></div><div className="modal-actions"><button type="button" onClick={onClose}>Cancelar</button><button className="primary" type="submit">Salvar cadastro</button></div></form></Modal> }
function OccurrenceModal({ onClose, onSave }) { return <Modal title="Registrar ocorrência" onClose={onClose}><form onSubmit={onSave}><div className="form-grid"><label>Ocorrência<input name="event" required /></label><label>Local<input name="location" required /></label><label>Data<input name="date" placeholder="dd/mm/aaaa" /></label><label>Gravidade<select name="severity"><option>Baixa</option><option>Moderada</option><option>Alta</option></select></label><label>Status<select name="status"><option>Em análise</option><option>Resolvida</option></select></label></div><div className="modal-actions"><button type="button" onClick={onClose}>Cancelar</button><button className="primary" type="submit">Registrar</button></div></form></Modal> }
