export function MetricCard({ icon, tone = 'blue', label, value, note }) {
  return <article className="metric-card"><span className={`metric-icon ${tone}`}>{icon}</span><div><p>{label}</p><strong>{value}</strong><small>{note}</small></div></article>
}

export function StatusTag({ value }) {
  const tone = ['Operando', 'Resolvida', 'Baixa'].includes(value) ? 'ok' : ['Parada', 'Alta'].includes(value) ? 'danger' : 'warning'
  return <span className={`tag ${tone}`}>{value}</span>
}

export function BarChart({ data, color = 'blue' }) {
  return <div className="chart" aria-label="Gráfico semanal">{data.map(({ day, value }) => <div className="bar-column" key={day}><i className={color} style={{ height: `${value}%` }} /><span>{day}</span></div>)}</div>
}

export function EmptyState({ children }) { return <div className="empty-state">{children}</div> }
