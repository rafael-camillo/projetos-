export const initialMachines = [
  { id: 1, code: 'PR-004', name: 'Prensa Hidráulica 04', sector: 'Estamparia', status: 'Operando', efficiency: 96, maintenance: '12/07/2026' },
  { id: 2, code: 'ET-002', name: 'Esteira Transportadora 02', sector: 'Montagem', status: 'Manutenção', efficiency: 68, maintenance: '28/06/2026' },
  { id: 3, code: 'TC-001', name: 'Torno CNC 01', sector: 'Usinagem', status: 'Operando', efficiency: 91, maintenance: '03/07/2026' },
  { id: 4, code: 'EP-003', name: 'Empilhadeira 03', sector: 'Logística', status: 'Parada', efficiency: 25, maintenance: '15/05/2026' },
]

export const initialOccurrences = [
  { id: 1, date: '15/07/2026', event: 'Uso incorreto de EPI', location: 'Montagem A', severity: 'Moderada', status: 'Resolvida' },
  { id: 2, date: '10/07/2026', event: 'Área de circulação obstruída', location: 'Logística', severity: 'Baixa', status: 'Resolvida' },
  { id: 3, date: '04/07/2026', event: 'Quase acidente com empilhadeira', location: 'Expedição', severity: 'Alta', status: 'Em análise' },
]

export const production = [
  { day: 'Seg', value: 55 }, { day: 'Ter', value: 72 }, { day: 'Qua', value: 63 },
  { day: 'Qui', value: 88 }, { day: 'Sex', value: 77 }, { day: 'Sáb', value: 93 }, { day: 'Dom', value: 84 },
]
